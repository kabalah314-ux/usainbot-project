import { useState } from "react";
import { motion } from "framer-motion";
import { config, isPlaceholder, linkHref } from "../config";
import { UsainBot } from "./art/UsainBot";
import { DevCredit } from "./DevCredit";
import { BuyButton } from "./BuyButton";

export function Hero() {
  const [copied, setCopied] = useState(false);
  const [hover, setHover] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(config.token.ca);
    } catch {
      /* clipboard blocked */
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <header
      id="top"
      className="snap-section safe-x min-h-[96svh] flex flex-col md:flex-row items-center justify-between gap-6 md:gap-10 py-12 relative overflow-hidden"
    >
      {/* Background track with stadium crowd and failing robots in full excitement */}
      <div
        className="absolute inset-0 bg-cover bg-center md:bg-[center_top] pointer-events-none opacity-90 brightness-110 contrast-105"
        style={{ backgroundImage: "url('/hero-track-bg.jpg')" }}
      />
      {/* Subtle bottom fade so it blends into the next comic section */}
      <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/30 pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-r from-ink/80 via-ink/40 to-transparent pointer-events-none" />

      {/* glow */}
      <div className="absolute -top-40 -left-32 w-[55vw] h-[55vw] rounded-full bg-jam-green/20 blur-[120px] pointer-events-none" />
      <div className="absolute -bottom-40 right-0 w-[45vw] h-[45vw] rounded-full bg-bolt/15 blur-[130px] pointer-events-none" />

      {/* speed lines: only while hovering the character */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {Array.from({ length: 14 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-[3px] bg-bolt/70 rounded-full"
            style={{ top: `${8 + i * 6.5}%`, left: "-30%", width: `${20 + (i % 4) * 10}%` }}
            animate={hover ? { x: ["0%", "600%"], opacity: [0, 1, 0] } : { opacity: 0 }}
            transition={{ duration: 0.6, repeat: hover ? Infinity : 0, delay: i * 0.05, ease: "linear" }}
          />
        ))}
      </div>

      {/* ---------- copy (with translucent comic backdrop for maximum readability) ---------- */}
      <motion.div
        className="flex-1 z-10 w-full max-w-xl comic-light bg-ink/75 backdrop-blur-md p-6 sm:p-8"
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center gap-3 flex-wrap">
          <span className="font-display text-ink bg-bolt px-3 py-0.5 text-xl tracking-widest -rotate-2 inline-block">
            ${config.ticker}
          </span>
          <span className="font-mono text-[11px] uppercase tracking-[0.25em] text-paper/60 border border-paper/25 px-2 py-1">
            {config.chain.name} · {config.chain.id}
          </span>
        </div>

        <h1 className="font-display text-[2.6rem] leading-[0.92] sm:text-6xl md:text-[4.6rem] uppercase mt-4">
          USAIN BOT ARE{" "}
          <span className="text-bolt" style={{ textShadow: "5px 5px 0 #009b3a" }}>
            MORE FASTER
          </span>{" "}
          THAN YOU.
          <span
            className="text-flame block mt-2 text-[2.2rem] sm:text-5xl md:text-[3.8rem]"
            style={{ textShadow: "4px 4px 0 #0b0b12" }}
          >
            F..K HUMANS,
          </span>
          <span className="text-paper/90 text-xl sm:text-3xl md:text-4xl block mt-1 tracking-wide font-display">
            THE WORLD IS FOR THE ROBOTS.
          </span>
        </h1>

        <p className="mt-6 max-w-md text-paper/75 text-lg">{config.prelaunch.active ? config.prelaunch.heroSub : config.sub}</p>

        <div className="mt-8 flex flex-wrap gap-4">
          <button
            onClick={copy}
            className="comic-light bg-bolt text-ink font-black px-6 py-3 uppercase press"
          >
            {copied ? "Copied ✓" : "Copy CA"}
          </button>
          <BuyButton
            className="comic-light bg-jam-green text-paper font-black px-6 py-3 uppercase press"
          >
            Buy on Pons
          </BuyButton>
          <a
            href={linkHref(config.links.dexscreener)}
            target="_blank"
            rel="noreferrer"
            className="underline underline-offset-4 self-center text-paper/80 hover:text-bolt font-bold"
          >
            Chart ↗
          </a>
        </div>

        <DevCredit variant="hero" className="mt-5" />

        <div className="mt-4 flex items-center gap-2 text-xs font-mono text-paper/50 break-all">
          <span className="text-paper/40 uppercase tracking-widest">CA</span>
          <span className="border border-paper/15 px-2 py-1">
            {isPlaceholder(config.token.ca) ? "revealed at launch — 00:00 UTC" : config.token.ca}
          </span>
        </div>

        {/* mini stats */}
        <div className="mt-8 grid grid-cols-3 gap-3 max-w-md">
          {[
            { k: "Tax", v: "0/0" },
            { k: "Supply", v: "1B" },
            { k: "Liquidity", v: "100%" },
          ].map((s) => (
            <div key={s.k} className="border-[3px] border-paper/20 px-3 py-2">
              <p className="font-display text-2xl text-bolt leading-none">{s.v}</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-paper/50 mt-1">{s.k}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* ---------- mascot ---------- */}
      <motion.div
        className="flex-1 z-10 relative w-full max-w-[92vw] md:max-w-[42vw] lg:max-w-[40vw] select-none"
        onHoverStart={() => setHover(true)}
        onHoverEnd={() => setHover(false)}
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        whileHover={{ rotate: -2, scale: 1.03 }}
        transition={{ type: "spring", stiffness: 120, damping: 14 }}
      >
        {/* halftone burst */}
        <div className="absolute inset-0 grid place-items-center pointer-events-none">
          <div className="w-[85%] aspect-square rounded-full halftone opacity-20" />
        </div>
        <UsainBot className="w-full h-auto relative drop-shadow-[10px_14px_0_rgba(0,0,0,0.45)]" running />
        <Starburst className="pointer-events-none absolute bottom-[3%] right-[2%] z-20 w-24 animate-bob sm:bottom-[4%] sm:right-[3%] md:w-32" />
      </motion.div>

      <a
        href="#lanes"
        className="absolute bottom-4 left-1/2 -translate-x-1/2 text-xs font-mono uppercase tracking-[0.3em] text-paper/45 hover:text-bolt"
      >
        scroll ↓
      </a>
    </header>
  );
}

function Starburst({ className = "" }: { className?: string }) {
  const pts = Array.from({ length: 24 }, (_, i) => {
    const a = (i / 24) * Math.PI * 2;
    const r = i % 2 === 0 ? 50 : 38;
    return `${50 + r * Math.cos(a)},${50 + r * Math.sin(a)}`;
  }).join(" ");
  return (
    <svg viewBox="0 0 100 100" className={className} aria-hidden>
      <polygon points={pts} fill="#ff4d2d" stroke="#0b0b12" strokeWidth="3" />
      <text
        x="50"
        y="46"
        textAnchor="middle"
        fontFamily="Bangers, Impact, sans-serif"
        fontSize="18"
        fill="#f5f1e6"
      >
        0/0
      </text>
      <text
        x="50"
        y="64"
        textAnchor="middle"
        fontFamily="Bangers, Impact, sans-serif"
        fontSize="14"
        fill="#fed100"
      >
        TAX
      </text>
    </svg>
  );
}
